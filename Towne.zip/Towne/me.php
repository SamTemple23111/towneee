<?php
$send="bradfordbeldon@yahoo.com"// your email
?>